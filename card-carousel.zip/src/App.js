
import './App.css';
import Imagecarousel from './components/imagecarousel';

function App() {
  return (
    <div className="App">
      <Imagecarousel/>
    </div>
  );
}

export default App;
